class IOError extends Error {
    constructor(message) {
        super(message);
        this.name = 'IOError';
    }
}

class LSFS {
    static tree() {
        return JSON.parse(localStorage.getItem('lsfs'));
    }

    static cd(fullpath) {
        const tokens = fullpath.split('/');
        let cwd = LSFS.tree();
        for (const token of tokens) {
            let found = false;
            for (const dir of cwd) {
                if (typeof dir === 'object' && dir.hasOwnProperty(token)) {
                    found = true;
                    cwd = dir[token];
                    break;
                }
            }
            if (!found) {
                throw new IOError(`Invalid Path: ${fullpath}. No such directory ${token}`);
            }
        }
        return cwd;
    }

    static parent(fullpath) {
        const tokens = fullpath.split('/');
        tokens.splice(tokens.length - 1, 1);
        return tokens.join('/');
    }

    static mkdir(fullpath) {
        const parentPath = LSFS.parent(fullpath);
        let cwd = LSFS.tree();
        const tokens = parentPath.split('/');
        for (const token of tokens) {
            let found = false;
            for (const dir of cwd) {
                if (typeof dir === 'object' && dir.hasOwnProperty(token)) {
                    found = true;
                    cwd = dir[token];
                    break;
                }
            }
        }
        const newDirName = fullpath.split('/');
        const data = {};
        data[newDirName[newDirName.length - 1]] = [];
        cwd.push(data);
    }
}

(() => {
    const data = localStorage.getItem('lsfs');
    try {
        JSON.parse(data);
    } catch (e) {
        console.warn(e);
        localStorage.setItem('lsfs', '[]');
        console.warn('The previous warning should be ignored: LSFS has been reinitialized');
    }
})();
